import numpy as np
import function
import matrix
import metrics.metrics as metrics
import visualization.plot as plot

class MLP:

    def __init__(self, input_size, hidden_size, output_size, learning_rate):
        self.hidden_weights = matrix.initialize_matrix(input_size, hidden_size)
        self.output_weights = matrix.initialize_matrix(hidden_size, output_size)
        self.hidden_bias = np.zeros((1, hidden_size))
        self.output_bias = np.zeros((1, output_size))
        self.learning_rate = learning_rate

    def feedforward(self, X):
        hidden_input_layer_aux = matrix.matmul(X, self.hidden_weights)
        input_hidden_layer = matrix.add(hidden_input_layer_aux, self.hidden_bias)
        output_hidden_layer = function.sigmoid(input_hidden_layer)
        input_exit_layer_aux = matrix.matmul(output_hidden_layer, self.output_weights)
        input_exit_layer = matrix.add(input_exit_layer_aux, self.output_bias)
        predicted_output = function.sigmoid(input_exit_layer)
        return predicted_output, output_hidden_layer

    def backpropagate(self, target, predicted_output, output_hidden_layer):
        error_aux = matrix.subtract(target, predicted_output)
        derive_predicted_output = function.sigmoid_derivative(predicted_output)
        error_info = matrix.multiply(error_aux, derive_predicted_output)
        weight_adjustment = matrix.matmul(output_hidden_layer.T, error_info) * self.learning_rate
        bias_adjustment = np.sum(error_info, axis=0, keepdims=True) * self.learning_rate
        return weight_adjustment, bias_adjustment

    def update_weights(self, weight_adjustment, bias_adjustment):
        self.output_weights += weight_adjustment
        self.output_bias += bias_adjustment

    def train(self, input_data, expected_output, epochs):
        for epoch in range(epochs):
            print("running...")
            print('Epoch: ', epoch)
            old_hidden_weights = self.hidden_weights.copy()
            old_output_weights = self.output_weights.copy()
            predicted_output, hidden_output_layer  = self.feedforward(input_data)
            weight_adjustment, bias_adjustment = self.backpropagate(expected_output, predicted_output, hidden_output_layer)
            self.update_weights(weight_adjustment, bias_adjustment)
            print('predicted_output')
            print(predicted_output)
            print('-----------------------------')
            if (old_hidden_weights == self.hidden_weights).all() and (old_output_weights == self.output_weights).all():
                break
