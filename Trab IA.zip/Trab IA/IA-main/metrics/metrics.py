import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import matrix
import numpy as np

def calculate_metrics(output_prediction, expected_output):
    loss = matrix.sum(output_prediction**2)
    true_positives = np.sum((output_prediction == 1) & (expected_output == 1))
    false_positives = np.sum((output_prediction == 1) & (expected_output == 0))
    true_negatives = np.sum((output_prediction == 0) & (expected_output == 0))
    false_negatives = np.sum((output_prediction == 0) & (expected_output == 1))

    accuracy = (true_positives + true_negatives) / len(expected_output)

    if true_positives + false_positives != 0:
        precision = true_positives / (true_positives + false_positives)
    else:
        precision = 0.0

    if true_positives + false_negativos != 0:
        recall = true_positives / (true_positives + false_negativos)
    else:
        recall = 0.0

    return loss, accuracy, precision, recall
