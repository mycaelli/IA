import numpy as np
import pandas as pd

# Definir o número de caracteres e o tamanho da matriz de características
num_caracteres = 1000
num_features = 15  # 5x3 matriz de características

# Gerar características aleatórias
X = np.random.randint(2, size=(num_caracteres, num_features))

# Gerar classes aleatórias (10 classes, por exemplo, dígitos de 0 a 9)
y = np.random.randint(10, size=(num_caracteres, 1))

# Combinar características e classes em um DataFrame
data = np.hstack((X, y))
columns = [f'feature_{i+1}' for i in range(num_features)] + ['class']
df = pd.DataFrame(data, columns=columns)

# Salvar o DataFrame em um arquivo CSV
caracteres_filepath = r'C:\Users\gui02\Downloads\Trab IA\IA-main\logic_gates\Caracteres_Completo.csv'
df.to_csv(caracteres_filepath, index=False)

print(f"Arquivo {caracteres_filepath} criado com sucesso.")
